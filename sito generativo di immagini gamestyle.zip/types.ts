
export enum GameStyle {
  MINECRAFT = 'A',
  LEGO = 'B',
  ROBLOX = 'C',
  FORTNITE = 'D',
  ANIME = 'E',
  PIXEL_ART = 'F',
  ARCADE = 'G'
}

export interface ThemeConfig {
  appBackground: string;
  panelBackground: string;
  accentColor: string;
  textColor: string;
  fontFamily: string;
  borderColor: string;
  borderStyle: string;
  buttonStyle: string;
  iconStyle: string;
  inputStyle: string; // New: For Terminal vs Drag-Drop look
  cardStyle: string; // New: For Cartridge look vs Card look
}

export interface StyleOption {
  id: GameStyle;
  name: string;
  description: string;
  icon: string;
  color: string;
  previewImage: string;
  theme: ThemeConfig;
}

export interface PromptResult {
  originalInput: string;
  style: GameStyle;
  refinedPrompt: string;
  imageUrl?: string;
}
