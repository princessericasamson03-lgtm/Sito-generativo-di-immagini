
import React from 'react';
import { StyleOption } from '../types';

interface StyleCardProps {
  style: StyleOption;
  isSelected: boolean;
  onSelect: (id: string) => void;
  activeTheme: any; // Using the theme of the current style for rendering logic
}

const StyleCard: React.FC<StyleCardProps> = ({ style, isSelected, onSelect }) => {
  // Use the card's OWN theme for its appearance
  const t = style.theme;

  return (
    <div
      onClick={() => onSelect(style.id)}
      className={`relative cursor-pointer group transition-all duration-300 overflow-hidden theme-transition
        ${t.borderStyle}
        ${t.cardStyle ? t.cardStyle : t.panelBackground}
        ${isSelected ? `ring-2 ring-offset-2 ${t.buttonStyle.split(' ')[0]}` : 'hover:opacity-90'}
      `}
    >
      {/* Cartridge Label Area */}
      <div className={`p-4 flex flex-col items-center text-center space-y-3 ${t.textColor} ${t.cardStyle ? 'bg-black/50 m-1' : ''}`}>
        <div className={`w-12 h-12 flex items-center justify-center text-3xl transition-transform group-hover:scale-110 ${t.iconStyle}`}>
          <i className={`fa-solid ${style.icon}`}></i>
        </div>
        <div>
          <h3 className={`${t.fontFamily} ${t.accentColor}`}>{style.name}</h3>
        </div>
      </div>
      
      {isSelected && (
        <div className={`absolute top-2 right-2 w-6 h-6 flex items-center justify-center ${t.buttonStyle} ${style.id === 'B' ? 'rounded-full' : ''}`}>
          <i className="fa-solid fa-check text-[10px]"></i>
        </div>
      )}
    </div>
  );
};

export default StyleCard;
