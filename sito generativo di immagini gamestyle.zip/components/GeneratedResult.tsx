
import React from 'react';
import { PromptResult, ThemeConfig } from '../types';

interface GeneratedResultProps {
  result: PromptResult;
  loading: boolean;
  originalImagePreview?: string | null;
  theme: ThemeConfig;
}

const GeneratedResult: React.FC<GeneratedResultProps> = ({ result, loading, originalImagePreview, theme }) => {
  if (!result.refinedPrompt && !loading) return null;

  return (
    <div className={`mt-8 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700 ${theme.fontFamily} ${theme.textColor}`}>
      
      {/* Comparison Area */}
      {(result.imageUrl || loading) && (
        <div className="space-y-4">
          <h2 className={`text-xl flex items-center gap-2 ${theme.accentColor}`}>
            <i className="fa-solid fa-layer-group"></i>
            Risultato
          </h2>
          
          <div className={`grid ${originalImagePreview ? 'grid-cols-1 md:grid-cols-2' : 'grid-cols-1'} gap-4`}>
            {/* Original Image */}
            {originalImagePreview && (
              <div className="space-y-2">
                <span className={`text-[10px] font-bold uppercase tracking-widest px-1 opacity-70`}>Originale</span>
                <div className={`relative overflow-hidden ${theme.panelBackground} ${theme.borderStyle} aspect-square p-2`}>
                  <img 
                    src={originalImagePreview} 
                    alt="Original Reference" 
                    className={`w-full h-full object-cover grayscale-[30%] opacity-80 ${theme.borderStyle}`}
                  />
                </div>
              </div>
            )}

            {/* Generated Image */}
            <div className="space-y-2">
              <span className={`text-[10px] font-bold uppercase tracking-widest px-1 ${theme.accentColor}`}>
                Stile {theme.fontFamily.includes('pixel') ? 'RETRO' : 'APPLICATO'}
              </span>
              <div className={`relative group overflow-hidden shadow-2xl ${theme.panelBackground} ${theme.borderStyle} aspect-square flex items-center justify-center p-2`}>
                {loading ? (
                  <div className="flex flex-col items-center gap-4">
                    <div className={`w-12 h-12 border-4 border-t-transparent animate-spin rounded-full ${theme.accentColor.replace('text-', 'border-')}`}></div>
                    <p className="opacity-60 text-xs">Generazione...</p>
                  </div>
                ) : result.imageUrl ? (
                  <img 
                    src={result.imageUrl} 
                    alt="AI Generated" 
                    className={`w-full h-full object-cover transition-transform duration-700 group-hover:scale-105 ${theme.borderStyle}`}
                  />
                ) : null}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default GeneratedResult;
