
import { GoogleGenAI } from "@google/genai";
import { GameStyle } from "../types";
import { SYSTEM_INSTRUCTION, PORTRAIT_VALIDATION_PROMPT } from "../constants";

export interface ImageInput {
  data: string; // base64
  mimeType: string;
}

export class GeminiService {
  private getAI() {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async validateIsPortrait(imageInput: ImageInput): Promise<boolean> {
    const ai = this.getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: imageInput.data,
              mimeType: imageInput.mimeType
            }
          },
          { text: PORTRAIT_VALIDATION_PROMPT }
        ]
      }
    });
    
    const text = response.text?.trim().toUpperCase();
    return text === 'YES';
  }

  async refinePrompt(userInput: string, style: GameStyle): Promise<string> {
    const ai = this.getAI();
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Input Utente: "${userInput}", Stile: ${style}`,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        temperature: 0.7,
      },
    });

    return response.text?.trim() || userInput;
  }

  async generateImage(prompt: string, imageInput?: ImageInput): Promise<string> {
    const ai = this.getAI();
    
    const structuralPrompt = imageInput 
      ? `Maintaining the exact composition, head pose, and framing of the attached image, re-imagine the person in the following style: ${prompt}`
      : prompt;

    const parts: any[] = [{ text: structuralPrompt }];
    
    if (imageInput) {
      parts.unshift({
        inlineData: {
          data: imageInput.data,
          mimeType: imageInput.mimeType
        }
      });
    }

    // Utilizzo di Gemini 2.5 Flash Image (Nano Banana standard)
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: parts
      },
      config: {
        imageConfig: {
          aspectRatio: "1:1"
        }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }

    throw new Error("Nessuna immagine generata dal modello.");
  }
}

export const geminiService = new GeminiService();
