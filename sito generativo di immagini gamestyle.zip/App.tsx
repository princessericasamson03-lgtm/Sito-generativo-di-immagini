
import React, { useState, useCallback, useRef } from 'react';
import { GameStyle, PromptResult } from './types';
import { STYLE_OPTIONS } from './constants';
import { geminiService, ImageInput } from './services/geminiService';
import StyleCard from './components/StyleCard';
import GeneratedResult from './components/GeneratedResult';

const App: React.FC = () => {
  const [selectedStyle, setSelectedStyle] = useState<GameStyle>(GameStyle.ARCADE);
  const [loading, setLoading] = useState(false);
  const [isValidating, setIsValidating] = useState(false);
  const [uploadedImage, setUploadedImage] = useState<ImageInput | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [result, setResult] = useState<PromptResult>({
    originalInput: '',
    style: GameStyle.ARCADE,
    refinedPrompt: ''
  });
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Get current active theme
  const activeOption = STYLE_OPTIONS.find(s => s.id === selectedStyle) || STYLE_OPTIONS[0];
  const t = activeOption.theme;
  const isArcade = selectedStyle === GameStyle.ARCADE;

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 4 * 1024 * 1024) {
        setError('L\'immagine è troppo grande. Limite 4MB.');
        return;
      }

      setIsValidating(true);
      setError(null);

      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64 = (reader.result as string).split(',')[1];
        const tempImage = {
          data: base64,
          mimeType: file.type
        };

        try {
          const isPortrait = await geminiService.validateIsPortrait(tempImage);
          if (isPortrait) {
            setUploadedImage(tempImage);
            setImagePreview(reader.result as string);
          } else {
            setError(isArcade ? 'ERRORE: SOGGETTO_NON_VALIDO' : 'Spiacente, carica solo RITRATTI.');
            if (fileInputRef.current) fileInputRef.current.value = '';
          }
        } catch (err: any) {
          setError('Errore durante la verifica dell\'immagine. Riprova.');
        } finally {
          setIsValidating(false);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setUploadedImage(null);
    setImagePreview(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleGenerate = async () => {
    if (!uploadedImage) {
      setError(isArcade ? 'ERRORE: NESSUN_INPUT' : 'Inserisci un ritratto per procedere!');
      return;
    }

    setLoading(true);
    setError(null);
    
    try {
      const promptToRefine = "A professional portrait in character style";
      const refined = await geminiService.refinePrompt(promptToRefine, selectedStyle);
      
      setResult(prev => ({ 
        ...prev, 
        refinedPrompt: refined, 
        originalInput: "RITRATTO", 
        style: selectedStyle, 
        imageUrl: undefined 
      }));
      
      const imageUrl = await geminiService.generateImage(refined, uploadedImage || undefined);
      setResult(prev => ({ ...prev, imageUrl }));
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'Errore durante la generazione.');
    } finally {
      setLoading(false);
    }
  };

  const handleStyleSelect = useCallback((id: string) => {
    setSelectedStyle(id as GameStyle);
  }, []);

  return (
    <div className={`min-h-screen pb-20 px-4 md:px-8 transition-colors duration-500 ${t.appBackground} ${t.fontFamily} ${t.textColor}`}>
      {/* Header */}
      <header className="pt-12 pb-8 text-center max-w-4xl mx-auto relative z-10">
        <h1 className={`text-4xl md:text-6xl mb-4 theme-transition ${t.accentColor} drop-shadow-md`}>
          {isArcade ? 'PORTRAIT_ARCHITECT.EXE' : 'Portrait Architect'}
        </h1>
        <p className={`text-lg md:text-xl opacity-80 ${t.textColor} uppercase`}>
          {isArcade ? '> I TUOI RITRATTI IN VERSIONE GAMING' : 'I tuoi ritratti in versione gaming'}
        </p>
      </header>

      <main className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10 relative z-10">
        
        {/* Left Column */}
        <div className="lg:col-span-5 space-y-6">
          
          <section className={`${t.panelBackground} p-5 ${t.borderStyle} theme-transition`}>
            <label className={`block text-xs font-bold uppercase tracking-widest mb-3 flex items-center justify-between ${t.accentColor}`}>
              <span>{isArcade ? '> 01 Ritratto' : '1. Carica un Ritratto'}</span>
              <span className={`text-[10px] opacity-70 font-normal normal-case`}>{isArcade ? '[IN_ATTESA_DATI]' : 'Van Gogh, Selfie, etc.'}</span>
            </label>
            
            {!imagePreview ? (
              <div 
                onClick={() => !isValidating && fileInputRef.current?.click()}
                className={`group cursor-pointer ${t.inputStyle} ${t.borderStyle} p-8 transition-all flex flex-col items-center gap-3`}
              >
                {isValidating ? (
                  <div className="flex flex-col items-center gap-2">
                    <div className={`w-8 h-8 border-4 border-t-transparent animate-spin rounded-full ${t.accentColor.replace('text-', 'border-')}`}></div>
                    <p className={`text-xs font-medium ${t.accentColor}`}>{isArcade ? 'SCANSIONE_BIOMETRICA...' : 'Analisi...'}</p>
                  </div>
                ) : (
                  <>
                    <div className={`w-12 h-12 flex items-center justify-center transition-colors ${t.iconStyle} ${t.borderStyle === 'rounded-full' ? 'bg-slate-100 rounded-full' : ''}`}>
                      <i className={`fa-solid ${isArcade ? 'fa-terminal' : 'fa-user-tie'} text-xl`}></i>
                    </div>
                    <div className="text-center">
                      <p className={`text-sm font-medium opacity-80 ${t.textColor}`}>
                        {isArcade ? (
                          <>
                            Carica_ritratto<span className="animate-blink">_</span>
                          </>
                        ) : 'Carica un volto'}
                      </p>
                    </div>
                  </>
                )}
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileChange} 
                  accept="image/*" 
                  className="hidden" 
                />
              </div>
            ) : (
              <div className={`relative overflow-hidden aspect-square border-2 ${t.borderColor} ${t.borderStyle} bg-black/10`}>
                <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-black/40 opacity-0 hover:opacity-100 transition-opacity flex items-center justify-center">
                  <button 
                    onClick={removeImage}
                    className="bg-red-500 hover:bg-red-600 text-white w-10 h-10 rounded-full flex items-center justify-center shadow-lg transition-transform"
                  >
                    <i className="fa-solid fa-xmark text-lg"></i>
                  </button>
                </div>
              </div>
            )}
          </section>

          <section className="space-y-4">
            <h2 className={`text-sm font-bold uppercase tracking-widest px-1 ${t.accentColor}`}>
              {isArcade ? '> 02 SELEZIONA_LO_STILE' : '2. Scegli lo Stile'}
            </h2>
            <div className="grid grid-cols-2 gap-3">
              {STYLE_OPTIONS.filter(s => s.id !== GameStyle.ARCADE).map((style) => (
                <StyleCard 
                  key={style.id} 
                  style={style} 
                  isSelected={selectedStyle === style.id} 
                  onSelect={handleStyleSelect}
                  activeTheme={t} 
                />
              ))}
            </div>
          </section>

          <button
            onClick={handleGenerate}
            disabled={loading || isValidating}
            className={`w-full py-4 text-lg font-bold flex items-center justify-center gap-3 transition-all ${t.buttonStyle} ${t.borderStyle} ${loading || isValidating ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {loading ? (
              <>
                <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin"></div>
                {isArcade ? 'ELABORAZIONE...' : 'Generazione...'}
              </>
            ) : (
              <>
                <i className={`fa-solid ${isArcade ? 'fa-coins' : 'fa-wand-magic-sparkles'}`}></i>
                {isArcade ? 'INSERISCI GETTONE (GENERA)' : 'Genera Avatar'}
              </>
            )}
          </button>

          {error && (
            <div className={`p-4 ${t.panelBackground} ${t.borderStyle} border-2 border-red-500 text-red-500 text-xs flex gap-3 animate-in fade-in zoom-in duration-300`}>
              <i className="fa-solid fa-triangle-exclamation mt-0.5"></i>
              <p>{error}</p>
            </div>
          )}
        </div>

        {/* Right Column */}
        <div className="lg:col-span-7">
          {result.refinedPrompt || loading ? (
            <div className="lg:sticky lg:top-8">
              <GeneratedResult 
                result={result} 
                loading={loading} 
                originalImagePreview={imagePreview} 
                theme={t}
              />
            </div>
          ) : (
            <div className={`h-full flex flex-col items-center justify-center text-center p-12 ${t.panelBackground} ${t.borderStyle} ${t.inputStyle} opacity-60 min-h-[600px]`}>
              <div className={`w-24 h-24 mb-6 flex items-center justify-center text-5xl opacity-50 ${t.iconStyle} ${t.borderStyle === 'rounded-full' ? 'bg-slate-100/50 rounded-full' : ''}`}>
                <i className={`fa-solid ${isArcade ? 'fa-ghost' : 'fa-user-astronaut'}`}></i>
              </div>
              <h3 className="text-xl font-bold mb-2">{isArcade ? 'IN_ATTESA_DEL_RITRATTO' : `Galleria ${activeOption.name}`}</h3>
              <p className="opacity-70 max-w-xs mx-auto">
                {isArcade ? 'IN_ATTESA_GIOCATORE_1...' : 'Carica un volto e scegli uno stile per iniziare la trasformazione.'}
              </p>
            </div>
          )}
        </div>
      </main>

      <footer className={`mt-20 text-center opacity-60 text-xs py-10 border-t ${t.borderColor} relative z-10`}>
        <p>&copy; 2024 PORTRAIT_ARCHITECT // {activeOption.name} SYS.VER.2.0</p>
      </footer>
    </div>
  );
};

export default App;
