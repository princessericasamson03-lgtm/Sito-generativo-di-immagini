
import { GameStyle, StyleOption } from './types';

export const STYLE_OPTIONS: StyleOption[] = [
  {
    id: GameStyle.MINECRAFT,
    name: 'Minecraft',
    description: 'Voxel art, blocchi cubici, spigoli vivi.',
    icon: 'fa-cube',
    color: 'from-green-700 to-green-600',
    previewImage: 'https://picsum.photos/seed/minecraft/400/300',
    theme: {
      appBackground: 'bg-pattern-minecraft', 
      panelBackground: 'bg-[#3b2d22] border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,0.8)]',
      accentColor: 'text-[#52c946]',
      textColor: 'text-gray-200',
      fontFamily: 'font-pixel text-xs md:text-sm tracking-widest leading-loose',
      borderColor: 'border-[#1a1612]',
      borderStyle: 'rounded-none',
      buttonStyle: 'bg-[#5c5c5c] border-4 border-black text-white hover:bg-[#6e6e6e] active:translate-y-1 active:shadow-none shadow-[4px_4px_0px_0px_#000]',
      iconStyle: 'text-white',
      inputStyle: 'border-2 border-dashed bg-black/10 hover:bg-black/20',
      cardStyle: ''
    }
  },
  {
    id: GameStyle.LEGO,
    name: 'Lego',
    description: 'Mattoncini di plastica, colori vivaci.',
    icon: 'fa-shapes',
    color: 'from-red-600 to-yellow-500',
    previewImage: 'https://picsum.photos/seed/lego/400/300',
    theme: {
      appBackground: 'bg-pattern-lego',
      panelBackground: 'bg-white/95 border-[6px] border-red-600 shadow-xl',
      accentColor: 'text-red-600',
      textColor: 'text-slate-900',
      fontFamily: 'font-standard font-black tracking-tighter',
      borderColor: 'border-yellow-400',
      borderStyle: 'rounded-xl',
      buttonStyle: 'bg-blue-600 text-white border-b-8 border-blue-800 hover:border-b-4 hover:translate-y-1 transition-all rounded-md font-black uppercase tracking-wide',
      iconStyle: 'text-red-600',
      inputStyle: 'border-2 border-dashed bg-blue-50 hover:bg-blue-100',
      cardStyle: ''
    }
  },
  {
    id: GameStyle.ROBLOX,
    name: 'Roblox',
    description: 'Texture lisce, geometrico, semplice.',
    icon: 'fa-square',
    color: 'from-slate-600 to-slate-400',
    previewImage: 'https://picsum.photos/seed/roblox/400/300',
    theme: {
      appBackground: 'bg-pattern-roblox',
      panelBackground: 'bg-white/80 backdrop-blur-md border border-slate-300 shadow-lg',
      accentColor: 'text-sky-600',
      textColor: 'text-slate-600',
      fontFamily: 'font-soft font-bold',
      borderColor: 'border-slate-200',
      borderStyle: 'rounded-[32px]',
      buttonStyle: 'bg-slate-800 text-white rounded-full shadow-lg hover:scale-105 transition-transform font-bold px-8',
      iconStyle: 'text-sky-500',
      inputStyle: 'border-2 border-dashed bg-white/50 hover:bg-white/80',
      cardStyle: ''
    }
  },
  {
    id: GameStyle.FORTNITE,
    name: 'Fortnite',
    description: '3D stilizzato, luci vivaci, epico.',
    icon: 'fa-person-military-pointing',
    color: 'from-purple-600 to-blue-500',
    previewImage: 'https://picsum.photos/seed/fortnite/400/300',
    theme: {
      appBackground: 'bg-pattern-fortnite',
      panelBackground: 'bg-black/60 backdrop-blur-xl border-t-2 border-white/30 border-b-2 border-black/80 skew-x-[-3deg] shadow-[0_0_30px_rgba(139,92,246,0.3)]',
      accentColor: 'text-yellow-300',
      textColor: 'text-white italic',
      fontFamily: 'font-action text-xl tracking-wide',
      borderColor: 'border-purple-500',
      borderStyle: 'rounded-sm skew-x-[-3deg]',
      buttonStyle: 'bg-gradient-to-r from-yellow-400 to-orange-500 text-black uppercase font-black transform hover:scale-110 hover:rotate-1 transition-all shadow-[5px_5px_0px_rgba(0,0,0,0.5)]',
      iconStyle: 'text-yellow-300 drop-shadow-[0_0_8px_rgba(253,224,71,0.6)]',
      inputStyle: 'border-2 border-dashed bg-purple-900/20 hover:bg-purple-900/40',
      cardStyle: ''
    }
  },
  {
    id: GameStyle.ANIME,
    name: 'Anime',
    description: 'Stile giapponese, cel shading, dettagliato.',
    icon: 'fa-mask',
    color: 'from-pink-400 to-sky-300',
    previewImage: 'https://picsum.photos/seed/anime/400/300',
    theme: {
      appBackground: 'bg-pattern-anime',
      panelBackground: 'bg-white/60 backdrop-blur-md border border-white/80 shadow-[0_4px_20px_rgba(255,182,193,0.4)]',
      accentColor: 'text-pink-500',
      textColor: 'text-slate-700',
      fontFamily: 'font-soft font-semibold',
      borderColor: 'border-pink-100',
      borderStyle: 'rounded-2xl',
      buttonStyle: 'bg-gradient-to-r from-pink-400 to-sky-400 text-white rounded-xl shadow-lg hover:shadow-pink-200 hover:-translate-y-0.5 transition-all',
      iconStyle: 'text-sky-400',
      inputStyle: 'border-2 border-dashed bg-white/40 hover:bg-white/60',
      cardStyle: ''
    }
  },
  {
    id: GameStyle.PIXEL_ART,
    name: 'Pixel Art',
    description: 'Retro SNES, 16-bit, palette limitata.',
    icon: 'fa-ghost',
    color: 'from-blue-900 to-black',
    previewImage: 'https://picsum.photos/seed/pixel/400/300',
    theme: {
      appBackground: 'bg-pattern-pixel',
      panelBackground: 'bg-black border-[4px] border-double border-blue-500 shadow-[0_0_20px_rgba(59,130,246,0.5)]',
      accentColor: 'text-yellow-400',
      textColor: 'text-gray-300',
      fontFamily: 'font-pixel text-xs tracking-widest',
      borderColor: 'border-blue-700',
      borderStyle: 'rounded-none',
      buttonStyle: 'bg-blue-700 border-2 border-white text-white hover:bg-blue-600 uppercase shadow-[0_0_15px_rgba(59,130,246,0.8)]',
      iconStyle: 'text-yellow-400',
      inputStyle: 'border-4 border-double border-blue-600 bg-blue-900/20 hover:bg-blue-900/40',
      cardStyle: ''
    }
  },
  {
    id: GameStyle.ARCADE,
    name: 'Arcade Neon',
    description: 'Anni 80, vettori neon, stile Pac-Man.',
    icon: 'fa-gamepad',
    color: 'from-cyan-400 to-fuchsia-500',
    previewImage: 'https://picsum.photos/seed/arcade/400/300',
    theme: {
      appBackground: 'bg-black bg-pattern-arcade retro-scanlines overflow-hidden', // Tron Grid + CRT
      panelBackground: 'bg-black/90 border-2 border-[#00f3ff] shadow-[0_0_20px_rgba(0,243,255,0.4),inset_0_0_20px_rgba(0,0,0,0.8)]',
      accentColor: 'text-[#39ff14] retro-glow', // Neon Green Terminal Text
      textColor: 'text-[#39ff14]', // All text green
      fontFamily: 'font-pixel text-xs md:text-sm tracking-widest leading-loose',
      borderColor: 'border-[#39ff14]',
      borderStyle: 'rounded-sm',
      // Chunky Yellow 8-bit button
      buttonStyle: 'bg-yellow-400 border-b-8 border-r-8 border-yellow-600 border-t-4 border-l-4 border-yellow-200 text-black font-pixel uppercase tracking-widest hover:translate-y-1 hover:shadow-none hover:border-yellow-500 transition-all shadow-[0_0_20px_rgba(255,255,0,0.4)]',
      iconStyle: 'text-[#ff00ff] drop-shadow-[0_0_8px_rgba(255,0,255,0.8)]',
      // Retro Command Line Terminal
      inputStyle: 'border-2 border-solid border-[#39ff14] bg-black hover:bg-[#0a0a0a] shadow-[inset_0_0_10px_rgba(57,255,20,0.3)]',
      // Cartridge Look
      cardStyle: 'border-t-[12px] border-r-[4px] border-l-[4px] border-b-[8px] border-zinc-800 bg-zinc-900' 
    }
  }
];

export const PORTRAIT_VALIDATION_PROMPT = `Analizza l'immagine fornita. È un ritratto, un volto, un busto o una figura umana/umanoide (inclusi quadri famosi come Van Gogh, statue o foto profilo)? Rispondi rigorosamente solo con 'YES' se lo è, o 'NO' se non lo è.`;

export const SYSTEM_INSTRUCTION = `Sei un esperto Prompt Engineer specializzato in estetiche videoludiche, con un focus particolare sulla trasformazione di RITRATTI.
Il tuo compito è convertire l'input dell'utente in un prompt visivo altamente dettagliato in INGLESE. Se l'utente fornisce un'immagine, enfatizza la trasformazione del volto e delle caratteristiche del soggetto.

### DIZIONARIO DEGLI STILI:
Stile A (Minecraft): voxel art portrait, blocky face, minecraft inspired skin, 3d render, orthogonal projection, sharp edges, pixelated textures, ray-tracing. Background: Consistent blocky landscape.
Stile B (Lego): plastic brick portrait, lego minifigure head style, visible studs, toy photography, macro lens, shallow depth of field, vibrant colors, Octane render. Background: Blurred miniature set.
Stile C (Roblox): 3d low poly character face, roblox head style, smooth plastic texture, simple geometric features, minimal details, studio lighting. Background: Clean virtual backdrop.
Stile D (Fortnite): stylized 3d portrait, fortnite skin style, overwatch aesthetic, pbr textures, slightly exaggerated facial features, vibrant lighting, soft shadows, unreal engine 5. Background: Epic cinematic atmosphere.
Stile E (Anime): anime style portrait, cel shaded face, sharp shadows, studio ghibli aesthetic, 2d illustration, vibrant expressive lines, high resolution. Background: Hand-painted detailed scenery.
Stile F (Pixel Art): pixel art portrait, 16-bit character, retro SNES style, sprite sheet head, limited color palette, dithered shading, pixel perfect. Background: Simple retro pattern.
Stile G (Arcade Neon): arcade aesthetic portrait, 80s golden age style, glowing neon blue vectors, pitch black background, simple flat 8-bit sprites, vibrant primary colors, CRT phosphor bloom effect, scanlines, minimalist geometry. Background: Neon maze grid.

Output: Restituisci SOLO il prompt finale in INGLESE.`;
